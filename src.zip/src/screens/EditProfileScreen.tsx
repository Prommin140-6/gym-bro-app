import React, { useEffect, useMemo, useState } from "react";
import { View, Text, Pressable, Alert, ScrollView } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import type { NativeStackScreenProps } from "@react-navigation/native-stack";

import { Screen } from "../components/ui/Screen";
import { Card } from "../components/ui/Card";
import { TextField } from "../components/ui/TextField";
import { PrimaryButton } from "../components/ui/PrimaryButton";
import { COLORS } from "../theme/colors";

import { useAuth } from "../services/AuthContext";
import { useUserProfile } from "../hooks/useUserProfile";
import { updateUserProfile } from "../services/firestoreProfile";
import type { ProfileStackParamList } from "../types/navigation";

type Props = NativeStackScreenProps<ProfileStackParamList, "EditProfile">;

function onlyDigits(s: string) {
  return s.replace(/[^\d]/g, "");
}

const EXERCISE_OPTIONS = [
  { key: "exercise_everyday", title: "Very active", desc: "Workout almost every day" },
  { key: "exercise_3_5_days_week", title: "Active", desc: "Workout 3–5 days / week" },
  { key: "exercise_1_2_days_week", title: "Lightly active", desc: "Workout 1–2 days / week" },
  { key: "not_exercise", title: "Sedentary", desc: "Little or no exercise" },
] as const;

const GOAL_OPTIONS = [
  { key: "lose_weight", title: "Lose weight", desc: "Reduce body fat gradually" },
  { key: "gain_weight", title: "Gain weight", desc: "Increase body weight & calories" },
  { key: "maintain_weight", title: "Maintain weight", desc: "Keep current body weight" },
  { key: "maintain_muscle", title: "Maintain muscle", desc: "Preserve muscle mass & strength" },
] as const;

export default function EditProfileScreen({ navigation }: Props) {
  const { user } = useAuth();
  const uid = user?.uid ?? null;
  const { profile, loading } = useUserProfile(uid);

  const initial = useMemo(() => {
    const weightKg = profile.weightKg ?? (profile as any).weight_kg;
    const heightCm = profile.heightCm ?? (profile as any).height_cm;
    const age = (profile as any).age;
    const sex = (profile as any).sex;
    const exerciseStyle =
      (profile as any).exerciseStyle ?? (profile as any).exercise_style;
    const goal = (profile as any).goal ?? (profile as any).goalType;

    return {
      weightKg: weightKg != null ? String(Math.round(Number(weightKg))) : "",
      heightCm: heightCm != null ? String(Math.round(Number(heightCm))) : "",
      age: age != null ? String(Math.round(Number(age))) : "",
      sex: (sex as "male" | "female" | undefined) ?? undefined,
      exerciseStyle: exerciseStyle as string | undefined,
      goal: goal as string | undefined,
    };
  }, [profile]);

  const [sex, setSex] = useState<"male" | "female" | undefined>(undefined);
  const [heightCm, setHeightCm] = useState("");
  const [weightKg, setWeightKg] = useState("");
  const [age, setAge] = useState("");
  const [exerciseStyle, setExerciseStyle] = useState<string | undefined>(undefined);
  const [goal, setGoal] = useState<string | undefined>(undefined);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (loading) return;
    setSex(initial.sex);
    setHeightCm(initial.heightCm);
    setWeightKg(initial.weightKg);
    setAge(initial.age);
    setExerciseStyle(initial.exerciseStyle);
    setGoal(initial.goal);
  }, [loading, initial]);

  const validate = () => {
    if (!uid) return "Not logged in";
    if (!sex) return "Please select sex";

    const h = Number(heightCm);
    const w = Number(weightKg);
    const a = Number(age);

    if (!h || h < 120 || h > 230) return "Height must be 120–230 cm";
    if (!w || w < 30 || w > 250) return "Weight must be 30–250 kg";
    if (!a || a < 10 || a > 100) return "Age must be 10–100";
    if (!exerciseStyle) return "Please select activity level";
    if (!goal) return "Please select goal";

    return null;
  };

  const onSave = async () => {
    const v = validate();
    if (v) {
      setError(v);
      return;
    }

    try {
      setSaving(true);
      setError(null);

      await updateUserProfile(uid!, {
        sex,
        heightCm: Number(heightCm),
        weightKg: Number(weightKg),
        age: Number(age),
        exerciseStyle,
        goal,
        goalType: goal,
      });

      Alert.alert("Saved", "Your profile has been updated.");
      navigation.goBack();
    } catch (e: any) {
      setError(e?.message ?? "Failed to save");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Screen>
      <ScrollView
        contentContainerStyle={{
          padding: 16,
          paddingBottom: 120, // เผื่อปุ่ม + safe area
          gap: 14,
          flexGrow: 1,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <Pressable
            onPress={() => navigation.goBack()}
            style={{
              width: 40,
              height: 40,
              borderRadius: 999,
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: COLORS.surface2,
              borderWidth: 1,
              borderColor: COLORS.border,
            }}
          >
            <Ionicons name="chevron-back" size={22} color={COLORS.text} />
          </Pressable>

          <Text style={{ color: COLORS.text, fontSize: 22, fontWeight: "900" }}>
            Edit Profile
          </Text>
        </View>

        {/* Basic info */}
        <Card style={{ gap: 14 }}>
          <View style={{ gap: 8 }}>
            <Text style={{ color: COLORS.text, fontWeight: "900" }}>Sex</Text>

            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable
                onPress={() => setSex("male")}
                style={[
                  pill,
                  { borderColor: COLORS.border, backgroundColor: COLORS.surface2 },
                  sex === "male" && pillActive,
                ]}
              >
                <Text
                  style={{
                    fontWeight: "900",
                    color: sex === "male" ? COLORS.text : COLORS.subtext,
                  }}
                >
                  Male
                </Text>
              </Pressable>

              <Pressable
                onPress={() => setSex("female")}
                style={[
                  pill,
                  { borderColor: COLORS.border, backgroundColor: COLORS.surface2 },
                  sex === "female" && pillActive,
                ]}
              >
                <Text
                  style={{
                    fontWeight: "900",
                    color: sex === "female" ? COLORS.text : COLORS.subtext,
                  }}
                >
                  Female
                </Text>
              </Pressable>
            </View>
          </View>

          <TextField
            label="Height (cm)"
            value={heightCm}
            onChange={(t) => setHeightCm(onlyDigits(t))}
            placeholder="e.g. 174"
            keyboardType="numeric"
          />

          <TextField
            label="Weight (kg)"
            value={weightKg}
            onChange={(t) => setWeightKg(onlyDigits(t))}
            placeholder="e.g. 66"
            keyboardType="numeric"
          />

          <TextField
            label="Age"
            value={age}
            onChange={(t) => setAge(onlyDigits(t))}
            placeholder="e.g. 22"
            keyboardType="numeric"
          />
        </Card>

        {/* Activity level */}
        <Card style={{ gap: 12 }}>
          <Text style={{ color: COLORS.text, fontWeight: "900", fontSize: 16 }}>
            Activity Level
          </Text>

          {EXERCISE_OPTIONS.map((o) => {
            const selected = exerciseStyle === o.key;
            return (
              <Pressable
                key={o.key}
                onPress={() => setExerciseStyle(o.key)}
                style={{
                  borderWidth: 2,
                  borderColor: selected ? COLORS.primary : COLORS.border,
                  backgroundColor: COLORS.surface2,
                  borderRadius: 16,
                  padding: 14,
                  gap: 6,
                }}
              >
                <Text style={{ color: COLORS.text, fontWeight: "900", fontSize: 16 }}>
                  {o.title}
                </Text>
                <Text style={{ color: COLORS.subtext, fontWeight: "700" }}>
                  {o.desc}
                </Text>
              </Pressable>
            );
          })}
        </Card>

        {/* Goal */}
        <Card style={{ gap: 12 }}>
          <Text style={{ color: COLORS.text, fontWeight: "900", fontSize: 16 }}>
            Goal
          </Text>

          {GOAL_OPTIONS.map((o) => {
            const selected = goal === o.key;
            return (
              <Pressable
                key={o.key}
                onPress={() => setGoal(o.key)}
                style={{
                  borderWidth: 2,
                  borderColor: selected ? COLORS.primary : COLORS.border,
                  backgroundColor: COLORS.surface2,
                  borderRadius: 16,
                  padding: 14,
                  gap: 6,
                }}
              >
                <Text style={{ color: COLORS.text, fontWeight: "900", fontSize: 16 }}>
                  {o.title}
                </Text>
                <Text style={{ color: COLORS.subtext, fontWeight: "700" }}>
                  {o.desc}
                </Text>
              </Pressable>
            );
          })}

          {error ? (
            <Text style={{ color: COLORS.danger, fontWeight: "800" }}>{error}</Text>
          ) : null}

          <PrimaryButton
            title={saving ? "Saving..." : "Save"}
            onPress={onSave}
            disabled={saving}
          />
        </Card>
      </ScrollView>
    </Screen>
  );
}

const pill = {
  flex: 1,
  borderWidth: 1,
  borderRadius: 999,
  paddingVertical: 12,
  alignItems: "center",
} as const;

const pillActive = {
  backgroundColor: COLORS.primary,
  borderColor: COLORS.primary,
} as const;
